### Want to use markdown to write your slides?

`python render.py` can do that for you.

Dependencies: jinja2, markdown.
